// time clock
setInterval(()=>{
    document.getElementById("time").innerHTML= new Date().toLocaleString()

    },1000)

    // form
     form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      form.classList.add('was-validated')
      }else alert("Submit Done")

    }, false)